//=============================================================================
// Copyright (c) 2001-2018 FLIR Systems, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

/**
 *	@example EnumerationEvents.cpp
 *
 *	@brief EnumerationEvents.cpp explores arrival and removal events on
 *	interfaces and the system. It relies on information provided in the
 *	Enumeration, Acquisition, and NodeMapInfo examples.
 *
 *	It can also be helpful to familiarize yourself with the NodeMapCallback
 *	example, as nodemap callbacks follow the same general procedure as
 *	events, but with a few less steps.
 *
 *	This example creates two user-defined classes: InterfaceEventHandler and
 *	SystemEventHandler. These child classes allow the user to define properties,
 *	parameters, and the event itself while the parent classes - ArrivalEvent,
 *	RemovalEvent, and InterfaceEvent - allow the child classes to interface
 *	with Spinnaker.
 */

#include "Spinnaker.h"
#include "SpinGenApi/SpinnakerGenApi.h"
#include <iostream>
#include <sstream> 

using namespace Spinnaker;
using namespace Spinnaker::GenApi;
using namespace Spinnaker::GenICam;
using namespace std;

// This class defines the properties and methods for device arrivals and removals
// on an interface. Take special note of the signatures of the OnDeviceArrival()
// and OnDeviceRemoval() methods. Also, enumeration events must inherit from
// InterfaceEvent whether they are to be registered to the system or an
// interface.
class InterfaceEventHandler : public InterfaceEvent
{
public:

    //
    // Set the constructor and destructor
    //
    // *** NOTES ***
    // Notice that the constructor sets the interface pointer and the destructor
    // clears it.
    //
    InterfaceEventHandler(InterfacePtr iface, unsigned int interfaceNum) : m_interface(iface), m_interfaceNum(interfaceNum) {};
    ~InterfaceEventHandler() { m_interface = nullptr; };

    // This method defines the arrival event on an interface. It prints out 
    // the device serial number of the camera arriving and the interface
    // number. The argument is the serial number of the camera that triggered
    // the arrival event.
    void OnDeviceArrival(uint64_t deviceSerialNumber)
    {
        cout << "Interface event handler:" << endl;
        cout << "\tDevice " << deviceSerialNumber << " has arrived on interface " << m_interfaceNum << "." << endl << endl;
    }

    // This method defines removal events on an interface. It prints out the
    // device serial number of the camera being removed and the interface
    // number. The argument is the serial number of the camera that triggered
    // the removal event.
    void OnDeviceRemoval(uint64_t deviceSerialNumber)
    {
        cout << "Interface event handler:" << endl;
        cout << "\tDevice " << deviceSerialNumber << " was removed from interface " << m_interfaceNum << "." << endl << endl;
    }

private:

    InterfacePtr m_interface;
    unsigned int m_interfaceNum;
};

// In the example, InterfaceEventHandler inherits from InterfaceEvent while
// SystemEventHandler inherits from ArrivalEvent and RemovalEvent. This is
// done for demonstration purposes and is not a constraint of the SDK. All 
// three event types - ArrivalEvent, RemovalEvent, and InterfaceEvent - can be 
// registered to interfaces, the system, or both.
class SystemEventHandler : public ArrivalEvent, public RemovalEvent
{
public:

    SystemEventHandler(SystemPtr system) : m_system(system) {};
    ~SystemEventHandler() {};

    // This method defines the arrival event on the system. It retrieves the
    // number of cameras currently connected and prints it out.
    void OnDeviceArrival(uint64_t deviceSerialNumber)
    {
        unsigned int count = m_system->GetCameras().GetSize();

        cout << "System event handler:" << endl;
        cout << "\tThere " << (count == 1 ? "is " : "are ") << count << (count == 1 ? " device " : " devices ") << "on the system." << endl << endl;
    }

    // This method defines the removal event on the system. It does the same
    // as the system arrival event - it retrieves the number of cameras 
    // currently connected and prints it out.
    void OnDeviceRemoval(uint64_t deviceSerialNumber)
    {
        unsigned int count = m_system->GetCameras().GetSize();

        cout << "System event handler:" << endl;
        cout << "\tThere " << (count == 1 ? "is " : "are ") << count << (count == 1 ? " device " : " devices ") << "on the system." << endl << endl;
    }

private:

    SystemPtr m_system;
};

// This function checks if GEV enumeration is enabled on the system.
void CheckGevEnabled(SystemPtr& pSystem)
{
    // Retrieve the System TL Nodemap and EnumerateGEVInterfaces node
    INodeMap & nodeMap = pSystem->GetTLNodeMap();
    const CBooleanPtr enumerateGevInterfacesNode = nodeMap.GetNode("EnumerateGEVInterfaces");

    // Ensure the node is valid
    if (IsAvailable(enumerateGevInterfacesNode) && IsReadable(enumerateGevInterfacesNode))
    {
        const bool gevEnabled = enumerateGevInterfacesNode->GetValue();

        // Check if node is enabled
        if(!gevEnabled)
        {
            cout << endl << "WARNING: GEV Enumeration is disabled." << endl 
            << "If you intend to use GigE cameras please run the EnableGEVInterfaces shortcut" << endl 
            << "or set EnumerateGEVInterfaces to true and relaunch your application." << endl << endl;  
        }
        else
        {
            cout << "EnumerateGEVInterfaces is enabled. Continuing.." << endl;
        }
    }
    else
    {
        cout << "EnumerateGEVInterfaces node is unavailable" << endl;
    }
}

// Example entry point; this function sets up the example to act appropriately 
// upon arrival and removal events; please see Enumeration example for more 
// in-depth comments on preparing and cleaning up the system.
int main(int /*argc*/, char** /*argv*/)
{
    // Print application build information
    cout << "Application build date: " << __DATE__ << " " << __TIME__ << endl << endl;

    // Retrieve singleton reference to system object
    SystemPtr system = System::GetInstance();

    // Print out current library version
    const LibraryVersion spinnakerLibraryVersion = system->GetLibraryVersion();
    cout << "Spinnaker library version: "
        << spinnakerLibraryVersion.major << "."
        << spinnakerLibraryVersion.minor << "."
        << spinnakerLibraryVersion.type << "."
        << spinnakerLibraryVersion.build << endl << endl;

    // Check if GEV enumeration is enabled.
    CheckGevEnabled(system);

    // Retrieve list of cameras from the system
    CameraList camList = system->GetCameras();

    unsigned int numCameras = camList.GetSize();

    cout << "Number of cameras detected: " << numCameras << endl << endl;

    //
    // Retrieve list of interfaces from the system
    //
    // *** NOTES ***
    // MacOS interfaces are only registered if they are active. 
    // For this example to have the desired outcome all devices must be connected 
    // at the beginning and end of this example in order to register and deregister 
    // an event handler on each respective interface.
    //
    InterfaceList interfaceList = system->GetInterfaces();

    unsigned int numInterfaces = interfaceList.GetSize();

    cout << "Number of interfaces detected: " << numInterfaces << endl << endl;

    cout << endl << "*** CONFIGURING ENUMERATION EVENTS ***" << endl << endl;

    //
    // Create interface event for the system
    //
    // *** NOTES ***
    // The SystemEventHandler has been constructed to accept a system object in 
    // order to print the number of cameras on the system.
    //
    SystemEventHandler systemEventHandler(system);

    //
    // Register interface event for the system
    //
    // *** NOTES ***
    // Arrival, removal, and interface events can all be registered to 
    // interfaces or the system. Do not think that interface events can only be
    // registered to an interface. An interface event is merely a combination
    // of an arrival and a removal event.
    //
    // *** LATER ***
    // Arrival, removal, and interface events must all be unregistered manually.
    // This must be done prior to releasing the system and while they are still
    // in scope.
    //
    system->RegisterInterfaceEvent(systemEventHandler);

    //
    // Create and register interface event to each interface
    //
    // *** NOTES ***
    // The process of event creation and registration on interfaces is similar
    // to the process of event creation and registration on the system. The 
    // class for interfaces has been constructed to accept an interface and an
    // interface number (this is just to separate the interfaces).
    // 
    // *** LATER ***
    // Arrival, removal, and interface events must all be unregistered manually.
    // This must be done prior to releasing the system and while they are still
    // in scope.
    //
    vector<InterfaceEventHandler*> interfaceEvents;

    for (unsigned int i = 0; i < numInterfaces; i++)
    {
        // Select interface
        InterfacePtr pInterface = interfaceList.GetByIndex(i);

        // Create interface event
        InterfaceEventHandler* interfaceEventHandler = new InterfaceEventHandler(pInterface, i);
        interfaceEvents.push_back(interfaceEventHandler);

        // Register interface event
        pInterface->RegisterEvent(*interfaceEvents[i]);

        cout << "Event handler registered to interface " << i << "..." << endl;
    }

    // Wait for user to plug in and/or remove camera devices
    cout << endl << "Ready! Remove/Plug in cameras to test or press Enter to exit..." << endl << endl;
    getchar();

    //
    // Unregister interface event from each interface
    //
    // *** NOTES ***
    // It is important to unregister all arrival, removal, and interface events
    // from all interfaces that they may be registered to. 
    //
    for (unsigned int i = 0; i < numInterfaces; i++)
    {
        interfaceList.GetByIndex(i)->UnregisterEvent(*interfaceEvents[i]);

        // Delete interface event (because it is a pointer)
        delete interfaceEvents[i];
    }

    cout << "Event handler unregistered from interfaces..." << endl;

    //
    // Unregister system event from system object
    //
    // *** NOTES ***
    // It is important to unregister all arrival, removal, and interface events
    // registered to the system.
    //
    system->UnregisterInterfaceEvent(systemEventHandler);

    cout << "Event handler unregistered from system..." << endl;

    // Clear camera list before releasing system
    camList.Clear();

    // Clear interface list before releasing system
    interfaceList.Clear();

    // Release system
    system->ReleaseInstance();

    cout << endl << "Done! Press Enter to exit..." << endl;
    getchar();

    return 0;
}
